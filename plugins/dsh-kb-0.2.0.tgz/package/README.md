# dsh-kb — 数译知识库插件

把一座「带页码、带来源、带可信度」的数学文献资料卡库，接成 DeepSeek Harness 里
**任何 agent 都能直接调用**的检索工具。

它不是一个通用 RAG：检索单位是**一张结构化的卡**（谁、在什么书、第几页、什么等级的来源、
核对到哪一步），而不是切碎的文本块。因此每条结果都能回源核对，而不是给出一个无法追责的答案。

## 安装（本地 bundle）

```powershell
# 在 DSH 里
plugin_manager({ action: "install_bundle", target: "file:C:/Users/admin/Desktop/数译发布/dsh-kb" })
```

安装后需要重启 DSH 桌面端，工具才会出现在会话里。

配置（可选，写在 profile 的插件配置里）：

```yaml
repo:   "C:\\Users\\admin\\Desktop\\数译发布\\gitee_shuyi"   # 含 kb/ 的仓库根
python: "C:\\Users\\admin\\.dsh\\dsh-runtimes\\dsh-primary-runtime\\dependencies\\python\\python.exe"
timeoutMs: 30000
```

数据层不在插件里：插件只“调用 + 渲染”，库是仓库中的 `kb/shuyi.db`。
换库、换机器只改配置，不用改插件。

## 四个工具

| 工具 | 用途 | 典型问法 |
|---|---|---|
| `kb_search` | 全文检索（默认只查已核卡） | 「Hecke 特征层 的定义在哪本书第几页？」 |
| `kb_card` | 读单卡全文（依赖/来源/证据引文） | 「展开 glc.concept.hecke-eigensheaf-oper」 |
| `kb_brief` | 阅读前置包：动笔前的“已知内容地图” | 「我要译顶点代数，先给我相关卡」 |
| `kb_stats` | 库现状 + 风险队列 | 「哪些卡被查得多但还没复核？」 |

## 行为契约（写在工具描述里，模型可见）

1. 结果必带 `status`（verified/checked/disputed/draft）、`pages`、`sources`、`caveat`。
2. 默认不返回 `draft`（未复核）；显式 `include_draft` 才返回，且标注“未复核”。
3. 命中只代表「某部作品可能讲过」，**不构成结论**；引用前用页码回原文核对。
4. 矛盾不合并：`rel=contradicts` 的两张卡成对出现。

## 依赖

- 有 SQLite FTS5 + trigram 的 Python 3.8+（DSH 运行时自带的 python 即可）。
- 库由 `kb/ingest.py` → `kb/build_kb.py` 生成，见仓库 `kb/README.md`。

## 许可

插件代码 CC BY 4.0；卡片内容随仓库（译文 CC BY-NC-SA 4.0，语料与元数据 CC BY 4.0）。
